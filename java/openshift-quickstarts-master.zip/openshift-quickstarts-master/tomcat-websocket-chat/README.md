Websocket Chat Example
======================

This example can be used to demonstrate a working Tomcat deployment on OpenShift.  The example is derived from the Apache Tomcat Websocket Chat example, packaged for compilation and deployment using the Red Hat Tomcat images on OpenShift.

Access the application 
---------------------

Once deployed on OpenShift the application can be access through the URL http://<hostname>/websocket-chat
